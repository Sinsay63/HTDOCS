<?php
    require ('models/connexion_bdd.php');
    require('view/header.php');
    require('models/search_all_posts.php');
    require('view/list_posts.php');
    require('view/footer.php');