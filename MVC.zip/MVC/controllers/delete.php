<?php 
require ('models/connexion_bdd.php');
require('models/delete_post.php');
header('location: index.php');