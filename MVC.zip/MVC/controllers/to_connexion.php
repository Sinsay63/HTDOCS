<?php
require("view/header.php");
require("view/form_login.php");
require('view/footer.php');
