<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <footer>
            <p>Réalisé par Yanis HOUDIER </p>
        </footer>
    </body>
</html>