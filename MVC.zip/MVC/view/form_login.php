<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
    </head>
    <body> 
        <form action="index.php?page=connecté" method="post">
            <div>
                <label>
                <p>Votre pseudo:</p> 
                <input type="text" name="pseudo">
                </label>
                <label>
                    <p>Votre mot de passe:</p>
                    <input type="password" name="password">
                </label>
                <div>
                    <input type="submit" value="Se connecter">
                </div>
            </div>
        </form>
    </body>
</html>



