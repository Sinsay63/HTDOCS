<?php
    require('models/connexion.php');
    require('view/header.php');
    require('models/search_all_posts.php');
    require('view/list_posts.php');