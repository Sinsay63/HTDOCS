<?php 
require ('models/connexion.php');
require('models/delete_post.php');
