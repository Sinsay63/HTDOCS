<?php
require('models/connexion.php');
require('view/header.php');
require('models/info_profile.php');
require('view/modif_profil.php');
